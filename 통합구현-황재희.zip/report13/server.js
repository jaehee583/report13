const express = require('express');
const app = express();

// 중간프로그램(미들웨어)
app.use(express.static(__dirname + '/blog'));



//서버오픈
app.listen(8080,()=>{
  console.log('8080포트가 열렸습니다.');
  
})